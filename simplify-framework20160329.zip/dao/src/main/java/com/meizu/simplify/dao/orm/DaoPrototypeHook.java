package com.meizu.simplify.dao.orm;
/**
  * <p><b>Title:</b><i>TODO</i></p>
 * <p>Desc: TODO</p>
 * <p>source folder:{@docRoot}</p>
 * <p>Copyright:Copyright(c)2014</p>
 * <p>Company:meizu</p>
 * <p>Create Date:2016年1月11日 上午10:51:31</p>
 * <p>Modified By:luchuangye-</p>
 * <p>Modified Date:2016年1月11日 上午10:51:31</p>
 * @author <a href="mailto:luchuangye@meizu.com" title="邮箱地址">luchuangye</a>
 * @version Version 0.1
 *
 */

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.meizu.simplify.config.PropertiesConfig;
import com.meizu.simplify.config.annotation.Config;
import com.meizu.simplify.dao.annotations.Entity;
import com.meizu.simplify.dao.exception.BaseDaoException;
import com.meizu.simplify.ioc.BeanEntity;
import com.meizu.simplify.ioc.BeanFactory;
import com.meizu.simplify.ioc.annotation.BeanHook;
import com.meizu.simplify.ioc.prototype.IBeanPrototypeHook;
import com.meizu.simplify.utils.ClassUtil;
import com.meizu.simplify.utils.CollectionUtil;
import com.meizu.simplify.utils.PropertieUtil;
import com.meizu.simplify.utils.ReflectionUtil;

@BeanHook(Dao.class)
public class DaoPrototypeHook implements IBeanPrototypeHook {

	private static final Logger LOGGER = LoggerFactory.getLogger(DaoPrototypeHook.class);

	@Override
	public List<BeanEntity<?>> hook(Class<?> clazz) {
		
		LOGGER.debug("开始初始化Dao实例....");
		List<BeanEntity<?>> list = new ArrayList<>();
		List<Class<?>> entityClasses = ClassUtil.findClassesByAnnotationClass(Entity.class, "com.meizu");//扫描Entity注解的实体，获取实体列表
//		循环ORM对象列表
		if (CollectionUtil.isNotEmpty(entityClasses)) {
			for (Class<?> entityClass : entityClasses) {

				String beanName = entityClass.getSimpleName();
				char[] chars = beanName.toCharArray();
				chars[0] = Character.toLowerCase(chars[0]);
				beanName = new String(chars) + "BaseDao";
				BeanEntity<Object> beanEntity = new BeanEntity<>();
				beanEntity.setName(beanName);
				Object dao = buildDaoObject(clazz, entityClass);
				beanEntity.setBeanObj(dao);
				list.add(beanEntity);
				LOGGER.info("已注入bean:DAO[{}]", beanName);
			}
		}
		
		return list;
	}

	/**
	 * 
	 * 方法用途: 构建dao对象<br>
	 * 操作步骤: 分析注解和泛型参数，并设置构造函数带泛型的参数值，最后初始化Dao，设置构造函数参数<br>
	 * @param clazz
	 * @param entityClass
	 * @return
	 */
	private Object buildDaoObject(Class<?> clazz, Class<?> entityClass) {
		Object dao = null;
		try {
			Constructor<?> constructor = clazz.getDeclaredConstructor(Class.class);
			dao = ReflectionUtil.instantiateClass(constructor,entityClass);
		} catch (NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
			throw new BaseDaoException("构建dao对象失败",e);
		}
		return dao;
	}
	

}
