package com.meizu.simplify.mvc.exception;




/**
 * <p><b>Title:</b><i>未测试，未规划，未使用</i></p>
 * <p>Desc: TODO</p>
 * <p>source folder:{@docRoot}</p>
 * <p>Copyright:Copyright(c)2014</p>
 * <p>Company:meizu</p>
 * <p>Create Date:2016年1月28日 下午3:14:01</p>
 * <p>Modified By:luchuangye-</p>
 * <p>Modified Date:2016年1月28日 下午3:14:01</p>
 * @author <a href="mailto:luchuangye@meizu.com" title="邮箱地址">luchuangye</a>
 * @version Version 0.1
 *
 */
//@ControllerAdvice
public class GlobalExceptionResolver {

//	@ExceptionHandler
//	public @ResponseBody Exception handleBusinessException(HttpServletRequest request,
//			HttpServletResponse response, Object handler, Exception ex) {
//		return ex;
//	}

}
