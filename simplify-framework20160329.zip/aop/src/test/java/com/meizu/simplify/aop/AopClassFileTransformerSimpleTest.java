package com.meizu.simplify.aop;

import org.junit.Test;

public class AopClassFileTransformerSimpleTest {

	@Test
	public void test() {
		long start = System.currentTimeMillis();
		System.out.println(System.currentTimeMillis()-start);
	}
}
